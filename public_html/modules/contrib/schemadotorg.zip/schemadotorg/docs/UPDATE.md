Schema.org Blueprints: Updating
-------------------------------

- [ ] Diff changes via https://github.com/schemaorg/schemaorg/compare/v29.1-release...v29.4-release
- [ ] Update `\Drupal\schemadotorg\SchemaDotOrgInstaller::VERSION`
- [ ] Update `data/[VERSION]`
- [ ] Run `ddev drush -y schemadotorg:download-schema`
- [ ] Run `ddev drush -y schemadotorg:update-schema`
- [ ] Run `ddev drush -y schemadotorg:translate-schema`
- [ ] Check [Schema.org: Names overview](https://schemadotorg.ddev.site/admin/reports/schemadotorg/docs/names)
      for issues. 
- [ ] Create update hook to update schema and schemadotorg.names.yml. 
      @see schemadotorg_update_10008()
- [ ] Run PHPUnit tests.
     
